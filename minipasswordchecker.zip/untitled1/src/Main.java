import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a password:");
        String password = input.nextLine();
        passwordChecker(password);

        }


        public static void passwordChecker(String password){
            int numofDig = 0;
            if(password.length() < 8) {
                System.out.println("Password must have at least 8 characters.");
                System.out.println("Invalid password.");
                return;
            }
            for(int i = 0; i<password.length(); i++) {
                char ch = password.charAt(i);
                if (!Character.isLetterOrDigit(ch)) {
                    System.out.println("Password can only have letters or numbers.");
                    System.out.println("Invalid password.");
                    return;
                }
                else if(Character.isDigit(ch)){
                    numofDig++;
                }
            }
            if(numofDig<2){
                System.out.println("Password must have at least 2 digits.");
                System.out.println("Invalid Password.");
                return;
            }
            System.out.println("Password is valid.");
        }

    }
